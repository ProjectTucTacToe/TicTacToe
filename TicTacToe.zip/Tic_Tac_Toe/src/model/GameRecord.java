package model;
import java.time.LocalDate; 

public class GameRecord {
private Player playerX;
private Player playerO;
private boolean result;
private LocalDate date;

}
