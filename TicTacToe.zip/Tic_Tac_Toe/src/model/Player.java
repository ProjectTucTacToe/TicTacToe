package model;

public class Player {
  private String name;
  private int numOfWins;
  private int numOfGames;
  private int numOfLoses;
  private GameRecord[] records;
  private float score;
  private GameRecord[] bestGames;
  private GameRecord[] newGames;
  

//Contructor arg
Player(String name){
	this.name=name;
	numOfWins=0;
	numOfGames=0;
	numOfLoses=0;
	score =0;
}








}