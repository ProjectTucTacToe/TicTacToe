package model;
//edo einai o perfect player

final public class Board {
	private String [][] gameBoard;
	private int availability;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
