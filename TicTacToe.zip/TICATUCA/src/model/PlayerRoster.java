package model;

import java.io.File;
import java.io.IOException;
import java.io.File;

public class PlayerRoster {
private Player[] listOfPlayers;
private int numOfPlayers;

public PlayerRoster() {
	
}


public void addPlayer(String name,int playerNum) {

// prepei na valoume methodous pou exoun sxesi me to GUI
// na kanoume add sto listofplayers
	
	Player playerObj = new Player(name);
	
	
	
	try {
	      File myObj = new File("Player"+playerNum+".txt");
	      if (myObj.createNewFile()) {
	        System.out.println("File created: " + myObj.getName());
	      } else {
	        System.out.println("File already exists.");
	      }
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	
}


private void findPlayerNames(){
	
};
private void findPlayer(){
};
private void findHallOfFame() {

};


}
