package model;
//edo einai o perfect player

final public class Board {
	private final char [][] gameBoard;
	private final Boolean legal;
	private final char win;
	private  Boolean turn;
	private int numOfX;
	private int numOfO;
	private int diff;
	
	public final static int LENGTH = 3;
	//CONSTRUCTOR
	public Board() {
		
		gameBoard = new char[LENGTH][LENGTH];
		
		for(char[] i : gameBoard) {
			for(char j : i) {
				
				j = ' ';
				
			}
			
		}
	    numOfX = 0;
	    numOfO=0;
	    diff=0;
		legal = true;
		win = ' ';
		turn = true;
	}
	
	//Counts number of X and O
	public void count() {

		for(int i=0;i<3; i++) {
			for(int j=0;j<3; j++) {
				if (gameBoard[i][j]=='X')
					numOfX++;
                 
				    }
			numOfO = 9 - numOfX;
				}
	
			}
	
  //Finds the difference of X and O
    public void diff() {
    	diff= numOfX-numOfO;
    
    }
    
    public void playerTurn() {
    	if(turn) {
			//placeX(pos);methodos gia na vazei to x sto tamplo
		turn=false;
		}
		else {
			//placeO(pos); methodos gia na vazei to o sto tamplo

			turn=true;
			
		}
    }
    
    public Boolean legal() {
    	count();
    	diff();
    	if(gameEnd()) {
    	
    	}
    	}
    	
    public Boolean gameEnd() {
    	
    	
    }
    }
    

