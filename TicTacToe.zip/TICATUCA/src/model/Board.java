package model;
//edo einai o perfect player

final public class Board {
	private char [][] gameBoard;
	private int availability;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
