package controller;

public class GameController {

}
