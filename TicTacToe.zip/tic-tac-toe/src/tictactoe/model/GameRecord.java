package tictactoe.model;

import java.util.Date;


/** 
  a class that described finished rounds
  contains: the 2 players their score when the round was played
  and the date that the round was played
  
  */

public final class GameRecord {

	

	private final Player playerX;
	private final Player playerO;
	private final double playerXScore;
	private final double playerOScore;
	private final Date Date;
	
	public GameRecord(Player playerX,Player playerO) {
	

		this.playerX = playerX;
		this.playerO = playerO;
		this.playerXScore = playerX.getScore();
		this.playerOScore = playerO.getScore();
		this.Date = new Date();
		
	}

	
	
	//********************** getters ************************
	
	
	public Player getPlayerX() {
		return playerX;
	}

	public Player getPlayerO() {
		return playerO;
	}

	public double getPlayerXScore() {
		return playerXScore;
	}

	public double getPlayerOScore() {
		return playerOScore;
	}

	public Date getDate() {
		return Date;
	}
	
	
	
	
	
}
