package tictactoe.model;

public class Player {

	
	private String name;
	
	private int numberOfWins;
	private int numberOfLoses;
	private int numberOfDraws;
	private double score;

	
	
	
	//not done yet
	
	
	
	
	
	
	
	
	
	
	
	
	public double getScore() {
		return score;
	}
	
}
