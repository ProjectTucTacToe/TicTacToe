package tictactoe.model;


/** a tic-tac-toe board which is represented by a 3x3 array and
  	can have X's and O's on it
 
 */


public final class GameBoard {
	
	private final char[][] board;
	// void = ' '  ,X = 'X' ,O = 'O'
	private final Boolean isLegal;
	private final char winner;
	private final char turn; // which player's turn
	
	
	public final static Byte BOARD_LENGTH = 3; // dont change it i could break the code
	
	public GameBoard() {
		
		board = new char[BOARD_LENGTH][BOARD_LENGTH];
		
		// board[lines][columns]
		
		
		for(char[] i : board) {//initialization
			for(char j : i) {
				
				j = ' ';
				
			}
			
		}
		isLegal = true;
		winner = ' ';
		turn = 'X';
	}
	
	public GameBoard(char[][] board) {
		
		this.board = new char[BOARD_LENGTH][BOARD_LENGTH];
		int count=0;
		
		for(int i=0; i<BOARD_LENGTH; i++) {//copies the board to this.board
			for(int j =0; j <BOARD_LENGTH; j++) {
				if((board[i][j] == ' ') || (board[i][j] == 'X') || (board[i][j] == 'O')) {
					this.board[i][j] = board[i][j];
				}else {
					this.board[i][j] = ' ';
				}
			}
			
		}
		if(this.isLegal()) { // turn winner and so on make sense only if the board is legal
			this.isLegal = true;
			this.winner = this.winner();
			
			// counts X
			for(int i =0; i<BOARD_LENGTH; i++) {
				for(int j=0;j<BOARD_LENGTH;j++) {
					if(this.board[i][j]== 'X') {
						count++;
					}
				}
			}
			//turn makes sense only if the board is not final;
			if(winner == ' ') {// if count is even then its X turn if its odd then its O turn
				
				if(count % 2 == 0) {
					turn = 'X';
				}else {
					turn = 'O';
				}
				
			}else {
				turn = ' ';
			}
			
		} 
		
		
		
		
		
		
		
		
	}

	
	

	
	
	/** checks to see if this board is legal */
	private Boolean isLegal(){
		

		
		
		
		
		/*
		  
		  
		  
		 	************************** THE CONDITIONS *************************************
		 	
		
			the board is legal if and only if the following conditions are met
			
			1) assuming the X starts first,
				the X must always be a move ahead or in the same move as O
				that means the difference = (number of X) - (the number of O) must be equal to either 0 or 1 at all times
				(if not then that means one or both players have played twice or more in a row making the board illegal)
				
				
			2) when a player wins, the game ends at his or her turn this means
				that if the difference = (number of X) - (the number of O) must be 1 if the X wins or 0 if the O wins
				(if not that means the game has carried on after a player has won making the board illegal)
				
				
				(otan enas pextis kanei triliza tha leme. a player has made a tic-tac-toe )
				
			3) only 1 player can have a tic tac toe in a given board .
			(if both players have a tic tac toe in the same board then that means the game has carried on after a player has won making the board illegal) 
			
			
			
			
			
			
			**************************WHY THEY WORK *************************
			
			if these 3 conditions are met the board is always legal
			
			the second condition is pretty clear 
			
			but what I want to explain is how the interaction between the first condition and the third 
			are enough to check more situations than they seem to be able to
			
			if the first condition is true then the most amount of X is 5 and the most amount of O are 4 
			so the first condition also makes sure that a player cannot have more than 1 tic tac toe with 
			the exception of X making 2 tic tac toes at the same time in the last round which is  perfectly legal
			also thse tic tac toes would share a tile which is the last placed one 
			(with 5  X  there cannot exist 2 tic tac toes which do not share a tile)
			
			unfortunately the first condition does not ensure that there won't be 2 tic tac toes by different players
			this is where the third condition comes in
			
			
			
			
			
			**************************IMPLEMENTATION *************************
			
			we can use less checks if we merge the first and the second condition
			
			we will count the number of X and O , find their difference
			
			we will check to see which player has made a tic tac toe
			
				if both then return false;
			
				if X then check if the difference is 1 if not then return false; 
			
				if O then check if the difference is 0 if not then return false;
			
				if none then check if the difference is either 1 or 0 if not then return false;
				
			if the board has made made it this far 
			return true;
			
			
			
		 */
		
		int numX = 0; //number of X's
		int numO = 0; //number of O's
		
		// counting X's and O's
		for(char[] i : board) {
			for(char j : i) {
				
				switch(j) {
				case 'X':
					
					numX++;
					
					break;
				case 'O':
					numO++;
					break;

				}
		
			}
		}
			
		// calculating the difference
		int difference = numX - numO;
		
		
		if(!this.isWinnerUnique()) {
			return false;
		}
		
		switch(this.winner()) {// NOT the variable winner because is legal might come before this variable is calculated
		case 'X':
				return (difference == 1);
				//no need for breaks since return terminated the method
		case 'O':		
				return (difference == 0);
				//no need for breaks since return terminated the method
		default:
			return true;
		}
		
		
		
		
		
	}
	
	
	
	/* checks to see if this board is a 3x3 array
	  and if every element corresponds to X O or void*/
	
	/* not used :(
	 
	private Boolean isBoardValid() {
		
		
		//first we must make sure the board is 3x3
		
		//to do that we check that the first array (the array of the arrays) has length 3
		if(this.board.length != 3) {
			return false;
		}
		
		
		// then we check each individual array to see if they have length 3
		// if at least 1 of them has not length 3 then the board is not 3x3
		
		for(char[] i : board) {
			
			if(i.length != 3) {
				return false;
			}
			
		}
		
		
		// finally if all of the above conditions are met
		// then the board is 3x3
		
		// after we need to check if each character corresponds to X O or void
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++){
				
				if((this.board[i][j] != ' ') && (this.board[i][j] != 'X') && (this.board[i][j] != 'O')) {
					return false;
				}
				
			}
		}
		
		//if the board made it this far is valid
		return true;
		
		
	}
	*/
	
	
	/** returns 'X' or 'O' depending on who has made tic tac toe
	  	if none, returns ' '
	 */
	private char winner(){
		// this method is mend to be called only if we know that the board is legal
		
		int count = 0;
		char temp = ' ';
		
		
		//checks lines for tic tac toe
		for(int i=0; i<BOARD_LENGTH; i++) {
			
			if(board[i][0] != ' ') {
				temp = board[i][0];
			}//the sets temp = the first (O or X)
			
			for(int j=0;j<BOARD_LENGTH; j++) {
				
				if(temp == board[i][j]) {//checks to see if the item on the board is equal to the first
					count ++; 
				}else {//if we get here then there cant be tic tact toe in this line
					break;
				}
				
			}
			if (count == 3) {
				return temp;
			}
			count =0;
		}
		
		// checks rows for tic tac toe
		for(int j=0; j<BOARD_LENGTH; j++) {
			if(board[0][j] != ' ') {
				temp = board[0][j];
			}
			for(int i=0;i<BOARD_LENGTH; i++) {
				
				if(temp == board[i][j]) {
					count ++;
				}else {
					break;
				}
				
				
				
			}
			if (count == 3) {
				return temp;
			}
			count =0;
		}
		
		
		
		
		
		int count2 =0; //will need a second counter
		
		temp = board[1][1];//only the player who has the middle can make tic tac toe in either diagonal
		
		
		//if the middle is empty then there cant be tic tac toe in either diagonal
		//also if the board has made it this far the board is not final
		if(temp == ' ') {
			return temp;
		}
		
		
		
		//checks both diagonals
		for(int i=0; i<3; i++) {
			if(board[i][i] == temp) {
				count++;
			}
			if(board[2-i][i] == temp) {
				count2++;
			}
		}
		
		if( (count ==3) || (count2 ==3 )) {
			return temp;
		}else {
			return ' ';
		} 
		
		
	}
	
	/** 
	  
	  returns false if both players have made tic tac toe 
	  returns true otherwise
	   
	   */
	
	private Boolean isWinnerUnique() {
		
		int count = 0;
		char temp = ' ';
		char winner = ' ';
		
		// simmilar to the previous method
		
		//checks lines for tic tac toe
		for(int i=0; i<BOARD_LENGTH; i++) {
			
			if(board[i][0] != ' ') {
				temp = board[i][0];
			}//the sets temp = the first (O or X)
			
			for(int j=0;j<BOARD_LENGTH; j++) {
				
				if(temp == board[i][j]) {//checks to see if the item on the board is equal to the first
					count ++; 
				}else {
					break;
				}
				
			}
			if ((count == 3) &&((winner == ' ') || (winner == temp))) {
				winner = temp;
			}else if(count== 3 ) {// if the count is 3 and the first condition isnt met then there are 2 winners
				return false;
			}
			
			count =0;
		}
		
		// checks rows for tic tac toe
		for(int j=0; j<BOARD_LENGTH; j++) {
			if(board[0][j] != ' ') {
				temp = board[0][j];
			}
			for(int i=0;i<BOARD_LENGTH; i++) {
				
				if(temp == board[i][j]) {
					count ++;
				}else {
					break;
				}
				
				
				
			}
			if ((count == 3) &&((winner == ' ') || (winner == temp))) {
				winner = temp;
			}else if(count== 3 ) {// if the count is 3 and the first condition isnt met then there are 2 winners
				return false;
			}
		}
		
		
		
		
		
		int count2 =0; //will need a second counter
		
		temp = board[1][1];//only the player who has the middle can make tic tac toe in either diagonal
		
		
		//if the middle is empty or occupied by the winner then there cant be tic tac toe in either diagonal from the other person
		//also if the board has made it this far it means the winner is unique
		if((winner == ' ' || winner == temp)) {
			return true;
		}
		
		
		
		//checks both diagonals
		for(int i=0; i<BOARD_LENGTH; i++) {
			if(board[i][i] == temp) {
				count++;
			}
			if(board[2-i][i] == temp) {
				count2++;
			}
		}
		
		if( ((count == 3) || (count2 == 3 )) && ((winner == ' ') || (winner == temp))) {
			return true;
		}else if((count ==3) || (count2 ==3 )){
			return false;
		} 
		
		return true;
		
		
	}
	
	
	/** 
	 
	 makes a move for the player who is their turn
	 returns a new game board does not modify the old one
	 returns this if the board is final or illegal
	 (lines and columns start from 0)
	  */
	
	public GameBoard makeMove(int line ,int colomn){
		
		GameBoard GB;
		char [][] temp = new char [BOARD_LENGTH][BOARD_LENGTH];
		
		
		if((this.winner != ' ')||(!this.isLegal)) {//you cannot make a move on a final or illegal board
			return this;
		}
		if((line >(BOARD_LENGTH-1)) || (colomn >(BOARD_LENGTH-1))) {//the coordinate are out of the board
			return this;
		}
		if(board[line][colomn] != ' ') {// you cannot make a move on a tile that somebody else has played on
			return this;
		}
		
		
		
		
		
		for(int i=0; i<BOARD_LENGTH; i++) {//copies the board to the temp and changes only the move
			for(int j =0; j <BOARD_LENGTH; j++) {
					if(!((i == line) && (j == colomn))) {
						temp[i][j] = this.board[i][j];
					}else {
						temp[line][colomn] = this.turn;
					}
				}
			}
			
		GB = new GameBoard(temp);
		
		return GB;// no need to check for the turn since the constructor will do that
		
		
		
	}
	
	//********************* GETTERS**************
	
	
	public char[][] getBoard() {
		return board;
	}

	public Boolean getIsLegal() {
		return isLegal;
	}

	public char getWinner() {
		return winner;
	}

	public char getTurn() {
		return turn;
	}
	
	
	
	
}
