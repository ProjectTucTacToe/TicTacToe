package model;


public class Player {
  private String name;
  private int numOfWins;
  private int numOfGames;
  private int numOfLoses;
  private int numOfDraws;
  private GameRecord[] records;
  private float score;
  private GameRecord[] bestGames;
  private GameRecord[] newGames;
  

//Contructor arg
Player(String name){
	this.name=name;
	numOfWins=0;
	numOfGames=0;
	numOfLoses=0;
	score = 0;
	newGames= new GameRecord[5];
	bestGames= new GameRecord[5];
}


public float scoreCalculator() {
	
	if(numOfGames==0) {
		score=0;
		return score;
	}
	else
	return score = 50*(2*numOfWins+numOfDraws)/numOfGames;
}
//mehtod gia ta 5 kalitera
/*public void topGames() {
	 for (int i = 0 ; i < numOfGames; i++) {

         for(int j=i+1; j<numOfGames; j++) {
      	   
         if( records [j].compareTo( records [i]) > 0 ) {
      	 
      	 GameRecord temp;
             temp=records[j];

             records[j]=records[i];

             records[i]=temp;
     
         }
		 
		 
		 
		 
	 }
	
	if (numOfWins >=5) {
		
		
		
	}
	 
	 
	 
}
}*/


//method gia ta 5 pio prosfata
public void newestGames() {
	
	   for (int i = 0 ; i < numOfGames; i++) {

           for(int j=i+1; j<numOfGames; j++) {
        	   
           if( records [j].compareTo( records [i]) > 0 ) {
        	 
        	 GameRecord temp;
               temp=records[j];

               records[j]=records[i];

               records[i]=temp;
       
           }


}
}
	   System.arraycopy(records, 0, newGames, 0, 5);
  
}

//method for sorting into 3 arrays
public void sort () {
	 for (int i = 0 ; i < numOfGames; i++) {
	 if (records[i].result == 1) {
	 
	 }
}
}


}


