package model;

import java.io.Serializable;

public class Player implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	
  private String name;
  private int numOfWins;
  private int numOfGames;
  private int numOfLoses;
  private int numOfDraws;
  private GameRecord[] records;
  private float score;
  private GameRecord[] bestGames;
  private GameRecord[] newGames;
  

//Contructor arg
public Player(String name,int numOfWins,int numOfGames,int numOfLoses,int numOfDraws, float score){
	this.name =name;
	this.numOfWins =numOfWins;
    this.numOfGames =numOfGames;
	this.numOfLoses=numOfLoses;
	this.numOfDraws=numOfDraws;
	this.score=score;
	this.records=new GameRecord[40];
	this.newGames= new GameRecord[5];
	this.bestGames= new GameRecord[5];
}

//Constructor no arc
public Player() {
	this.records=new GameRecord[40];
	this.newGames= new GameRecord[5];
	this.bestGames= new GameRecord[5];
	numOfWins=0;
	numOfGames=0;
	numOfLoses=0;
	score = 0;
}

//Getters Setters

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getNumOfWins() {
	return numOfWins;
}

public void setNumOfWins(int numOfWins) {
	this.numOfWins = numOfWins;
}

public int getNumOfGames() {
	return numOfGames;
}

public void setNumOfGames(int numOfGames) {
	this.numOfGames = numOfGames;
}

public int getNumOfLoses() {
	return numOfLoses;
}

public void setNumOfLoses(int numOfLoses) {
	this.numOfLoses = numOfLoses;
}

public int getNumOfDraws() {
	return numOfDraws;
}

public void setNumOfDraws(int numOfDraws) {
	this.numOfDraws = numOfDraws;
}

public GameRecord[] getRecords() {
	return records.clone();
}

public void setRecords(GameRecord[] records) {
	this.records = records;
}

public float getScore() {
	return score;
}

public void setScore(float score) {
	this.score = score;
}

public GameRecord[] getNewGames() {
	return newGames;
}

public void setNewGames(GameRecord[] newGames) {
	this.newGames = newGames;
}


//Methods

public float scoreCalculator() {
	
	if(numOfGames==0) {
		score=0;
		return score;
	}
	else
	return score = 50*(2*numOfWins+numOfDraws)/numOfGames;
}


//method gia ta 5 pio prosfata
public void newestGames() {
	
	   for (int i = 0 ; i < numOfGames; i++) {

           for(int j=i+1; j<numOfGames; j++) {
        	   
           if( records [j].compareTo( records [i]) > 0 ) {
        	 
        	 GameRecord temp;
               temp=records[j];

               records[j]=records[i];

               records[i]=temp;
       
           }


}
}
	   System.arraycopy(records, 0, newGames, 0, 5);
  
}

//Method to find who won
public int checkWin(GameRecord rec) {

	Player plerX=rec.getPlayerX();
	Player plerO=rec.getPlayerO();
	
	if(rec.getResult()==1) {
		if(this.name.equals(plerX.getName())) {
			return 1;
		}	
		else {
			return -1;
		}
	}
    if(rec.getResult()==-1) {
    	if(this.name.equals(plerO.getName())) {
			return 1;
		}	
		else {
			return -1;
		}
	}
    if(rec.getResult()==0) {
	    return 0;
    }
		
	return 2;
}

//Method to find the 5 best games of a player

public void BestGames(Player pler) {

 GameRecord[] recd=this.getRecords();
 GameRecord temp0=null;
 int num;
 int num1;
 boolean gmi;
 boolean gmj;
 
 
for (int i = 0 ; i < recd.length; i++) {
		
		if(recd[i]==null)
			break;
		else {
		    for( int j=i+1; j<recd.length; j++) {
		    	 if(recd[j]==null)
		 			break;
		    	 else {
		    		 num=checkWin(recd[i]);
		    		 num1=checkWin(recd[j]);
	                    if(num!=num1) {
	                    	if(num1>num) {
	                    		 temp0=recd[i];		    	       	           	     
	    	                     recd[i]=recd[j];       		    	       
	    	                     recd[j]=temp0;
	                    	}	                    	
	                    }
	                    if(num==num1){
	                      Player piX=recd[i].getPlayerX();
	                      Player piO=recd[i].getPlayerO();
	                      Player pjX=recd[j].getPlayerX();
	                      Player pjO=recd[j].getPlayerO();
	                      
	                    	if(this.name.equals(piX.getName())) {
	                    		if(piO.getScore()>this.score) {
	                    			gmi=true;
	                    		}
	                    		else {
	                    			gmi=false;
	                    		}	                    	
	                    	  	
	                    	}
	                    	else {
	                    		if(piX.getScore()>this.score) {
	                    			gmi=true;
	                    		}	
	                    		else {
	                    			gmi=false;
	                    		}
	                    	}
	                    	                    	
	                    	if(this.name.equals(pjX.getName())) {
	                    		if(pjO.getScore()>this.score) {
	                    			gmj=true;
	                    		}
	                    		else {
	                    			gmj=false;
	                    		}	                              	  	
	                    	}
	                    	else {
	                    		if(pjX.getScore()>this.score) {
	                    			gmj=true;
	                    		}	
	                    		else {
	                    			gmj=false;
	                    		}
	                    	}
	                    	
	                    	
	                    	if(gmj==true && gmi==false) {
	                    		temp0=recd[i];		    	       	           	     
			       	            recd[i]=recd[j];       		    	       
			       	            recd[j]=temp0;
	                    	}
	                    	
	                    	
	                    	if(gmi==gmj) {
	                    		if(recd[j].getDate().compareTo(recd[i].getDate())>0) {
	    	                 		temp0=recd[i];		    	       	           	     
	    		       	            recd[i]=recd[j];       		    	       
	    		       	            recd[j]=temp0;
	    	                  	}  
	                    	}
	                    	
	                    }
	                   	   	                    	    	       	                     	               
	            }
		    }	
	    }	
	 }
	
for(int i=0; i<recd.length; i++) {
	this.bestGames[i]=recd[i];
}
	
}



}

