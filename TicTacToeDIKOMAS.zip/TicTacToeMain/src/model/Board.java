package model;
//edo einai o perfect player

import controller.GameController;

final public class Board {
	private  char [][] gameBoard;
	private final Boolean legal;
	private  char win;
	private  Boolean turn; //true gia x false gia o
	private Player playerX;//selected players of the board
	private Player playerO;
	private boolean x;
	private boolean o;
	private int numOfX;
	private int numOfO;
	private int diff;
	GameController gc;
	public final static int LENGTH = 3;
	//CONSTRUCTOR
	public Board( GameController gc) {
		this.gc=gc;
		gameBoard = new char[LENGTH][LENGTH];
		
		for(char[] i : gameBoard) {
			for(char j : i) {
				
				j = ' ';
				
			}
			
		}
		x=false;
		o=false;
		playerX= new Player();
		playerO= new Player();
	    numOfX = 0;
	    numOfO=0;
	    diff=0;
		legal = true;
		win = ' ';
		turn = true;
	}
	
	//CONSTRUCTOR WHICH COPIES BOARD
	//EXOUME THEMATAKI EDO!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	public Board (GameController gc,char[][] gameBoard) {
	this.gc=gc;
	char [][] fake  = new char[LENGTH][LENGTH];
	
	//copies the board to fake
	for(int i=0;i<3; i++) {
		for(int j =0; j <3; j++) {
			if((gameBoard[i][j] == ' ') || (gameBoard[i][j] == 'X') || (gameBoard[i][j] == 'O')) {
				fake[i][j] = gameBoard[i][j];
			}else {
				fake[i][j] = ' ';
			}
		}
	}
		if (legal()) {//check if board is legal
			legal = true;
		    numOfX = 0;
		    numOfO=0;
		    diff=0;
			win = ' ';
			turn = true;
			if (gameEnd()) {
				System.out.println("Game has ended!");
			}
		
		}
		else {
			legal = false;
			win = ' ';
			turn=false;
		}
		
	}
	//method to select Players
	public void selectPlayer(char z, Player p) {
		if (z== 'x' ) {
			playerX= p;
			x=true;
		}
		if (z== 'o') {
			playerO= p;
			o=true;
		}
	}
	
	//method to check selected players
	//PAIZEI NA EINAI LATHOS GIATI TA PLAYERS EINAI OBJECT KAI OXI STRING
	public boolean ready() {
		return (x && o);
	}
	//oi start game in play kai no play einai gia controller kai model 
    //method to start the game with a blank board
	public void startGame() {
		gameBoard= new char[3][3];
	}
	//method to start the game without a blank board
	public void startGame( char[][] gb ) {
		gameBoard= gb;
	}
	
	
	public boolean inPlay() {
		return gameBoard !=null;
	}
	
	public boolean NoPlay() {
		return !inPlay();
	}
	
	//Counts number of X and O
	public void count() {

		for(int i=0;i<3; i++) {
			for(int j=0;j<3; j++) {
				if (gameBoard[i][j]=='X')
					numOfX++;
                 
				    }
			numOfO = 9 - numOfX;
				}
	
			}
	
  //Finds the difference of X and O
    public void diff() {
    	diff= numOfX-numOfO;
    
    }
    
    //method to find which player should play next
    public void playerTurn(int line, int column) {
    	if(turn) {
    		move(line, column);
			//placeX(pos);methodos gia na vazei to x sto tamplo
		turn=false;
		}
		else {
			move(line, column);
			//placeO(pos); methodos gia na vazei to o sto tamplo

			turn=true;
			
		}
    }
    
    //method to find if the game should end
 public Boolean gameEnd() {
	 horizontalTic();
	 verticalTic();
	 diagonalTic();
	 if(win != ' ') {
		return true; }
	 else 
		 return false;
	 }
 
 
		public void horizontalTic() {
			int j =0;
			for(int i=0; i<3; i++) {
				if(gameBoard[i][j] != ' ' && gameBoard[i][j+1]!= ' ' && gameBoard[i][j+2]!= ' ' )
				{
					if(gameBoard[i][j] == 'X' && gameBoard[i][j+1]=='X' && gameBoard[i][j+2]=='X' ) {
						System.out.println("X wins");
						win='X';
						System.exit(1);
					}
			    	if(gameBoard[i][j]=='O' && gameBoard[i][j+1]=='O' && gameBoard[i][j+2]=='O') {
			    		System.out.println("O wins");
			    		win='O';
						System.exit(1);
					}
				}	
			}
		}
		public void verticalTic() {
			int i =0;
			for(int j=0; j<3; j++) {
				if(gameBoard[i][j] != ' ' && gameBoard[i+1][j]!= ' ' && gameBoard[i+2][j]!= ' ' )
				{
					if(gameBoard[i][j] == 'X' && gameBoard[i+1][j]=='X' && gameBoard[i+2][j]=='X' ) {
						System.out.println("X wins");
						win='X';
						System.exit(1);
					}
			    	if(gameBoard[i][j]=='O' && gameBoard[i+1][j]=='O' && gameBoard[i+2][j]=='O') {
			    		System.out.println("O wins");
			    		win='O';
						System.exit(1);
					}
				}	
			}
		}

	public void diagonalTic() {
		
		if(gameBoard[0][0] != ' ' && gameBoard[1][1]!= ' ' && gameBoard[2][2]!= ' ' ) {
			if(gameBoard[0][0]=='X' && gameBoard[1][1]=='X' && gameBoard[2][2]=='X' ) {
				System.out.println("X wins");
				win='X';
				System.exit(1);
			}
			if(gameBoard[0][0]=='O' && gameBoard[1][1]=='O' && gameBoard[2][2]=='O' ) {
	    		System.out.println("O wins");
	    		win='O';
				System.exit(1);
			}
		}
		if(gameBoard [0][2]!='\0' && gameBoard[1][1]!='\0' && gameBoard[2][0]!='\0' ){
			if(gameBoard[0][2]=='X' && gameBoard[1][1]=='X' && gameBoard[2][0]=='X' ) {
				System.out.println("X wins");
				win='X';
				System.exit(1);
			}
			if(gameBoard[0][2]=='O' && gameBoard[1][1]=='O' && gameBoard[2][0]=='O' ) {
	    		System.out.println("O wins");
	    		win='O';
				System.exit(1);
			}
		}
	}	
   
	//method to make move for player
	public Board move(int line, int column) {
    Board b;
    char [][] fake = new char [LENGTH][LENGTH];
    if (legal()||gameEnd()) {//illegal board and or final board
   return this; }
    if((line >(LENGTH-1)) || (column >(LENGTH-1))) {//out of bounds
		return this;
	}
    if(gameBoard[line][column] != ' ') {//already taken
		return this;
	}
  //copies the board to fake and changes only the move
    for(int i=0; i<3; i++) {
		for(int j =0; j <3; j++) {
				if(!((i == line) && (j == column))) {
					fake[i][j] = this.gameBoard[i][j];
				}else {
					if(turn) {
					fake[line][column] = 'X';	
					}else {
					fake[line][column] = 'O';
					}
			}
		}
    }
	b = new Board(gc,fake);
	return b; // no need to check for the turn since the constructor will do that
	}
	
    
    //method to find if board is legal
    public Boolean legal() {
    	count();
    	diff();
    	if(!(diff==1 || diff==0 )) {
    		return false;
    	}
    	if(gameEnd()) {
    		return false;
    	}
    	else
    		return true;
    	}
    	
    }

