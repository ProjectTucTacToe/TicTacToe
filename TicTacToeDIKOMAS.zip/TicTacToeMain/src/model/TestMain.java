/*package model;
import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);	
	     System.out.println("enter name of player");
	     String nameOfPlayer = input.nextLine();
		
	    PlayerRoster obj = new PlayerRoster();
	    	  
	 //  obj.addPlayer(nameOfPlayer);	 
	   obj.findHallOfFame(); 
	 
	    
	   String name="mitsotakis";
	   int w=2;
	   int l=1;
	   int d=4;
	   int g=7;
	   float sc=54;
	   /*           
	   LocalDate dt1=LocalDate.of(2021,Month.AUGUST, 2);
	   LocalDate dt2=LocalDate.of(2021,Month.APRIL, 8);
	   LocalDate dt3=LocalDate.of(2021,Month.DECEMBER, 20);
	   LocalDate dt4=LocalDate.of(2021,Month.AUGUST, 23);
	   LocalDate dt5=LocalDate.of(2021,Month.DECEMBER, 21);
	   
	   GameRecord rec1= new GameRecord(new Player("giorgaras",w,l,d,g,80),new Player(name,w,l,d,g,sc));
	   rec1.setDate(dt1);
	   rec1.setResult(0);
	   GameRecord rec2= new GameRecord(new Player(name,w,l,d,g,sc),new Player("mpampinos",w,l,d,g,30));
	   rec2.setDate(dt2);
	   rec2.setResult(-1);
	   GameRecord rec3= new GameRecord(new Player("joemama",w,l,d,g,55),new Player(name,w,l,d,g,sc));
	   rec3.setDate(dt3);
	   rec3.setResult(-1);
	   GameRecord rec4= new GameRecord(new Player(name,w,l,d,g,sc),new Player("abelladanger",w,l,d,g,101));
	   rec4.setDate(dt4);
	   rec4.setResult(0);
	   GameRecord rec5= new GameRecord(new Player("johnny",w,l,d,g,21),new Player(name,w,l,d,g,sc));
	   rec5.setDate(dt5);
	   rec5.setResult(-1);
	   
	   GameRecord[] prec= {rec1,rec2,rec3,rec4,rec5};
	   */
	   Player objPler= new Player(name,w,l,d,g,sc);
	 //  objPler.checkWin();
	//   objPler.setRecords(prec);
	   
	   objPler.BestGames(objPler);
	   obj.loadListOfPlayers();
	   obj.storeListOfPlayers(objPler);
	   obj.loadListOfPlayers();
	   
	     input.close();

	}

}*/
