package view;

import java.awt.Graphics;

import javax.swing.JPanel;




public class Board extends JPanel{
	public Board() {
		
	}
	@Override
	public void paint(Graphics g) {
		int x = this.getWidth() / 2 - 50;
		int y = this.getHeight() / 2;
		g.drawString("Game Board", x, y);
	}


}
