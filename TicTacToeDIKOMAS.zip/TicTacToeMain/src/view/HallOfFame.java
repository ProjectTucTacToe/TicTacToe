package view;

import java.awt.Graphics;

import javax.swing.JPanel;



public class HallOfFame extends JPanel {
 public HallOfFame() {
	 
			super();
 }
	@Override
	public void paint(Graphics g) {
		int x = this.getWidth()/2 - 50;
		int y = this.getHeight()/2;		
		g.drawString("Hall Of Fame", x, y);
	}
}
