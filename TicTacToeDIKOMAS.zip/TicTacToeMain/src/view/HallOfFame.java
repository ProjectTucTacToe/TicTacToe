package view;

import java.awt.Graphics;

import javax.swing.JPanel;
import controller.GameController;


public class HallOfFame extends JPanel {
 public HallOfFame(GameController gc) {
	 
			super();
 }
	@Override
	public void paint(Graphics g) {
		int x = this.getWidth()/2 - 50;
		int y = this.getHeight()/2;		
		g.drawString("Hall Of Fame", x, y);
	}
}
