package view;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class MainArea extends JPanel{
	CardLayout slide;
	HallOfFame hall;
	Board board;
	public MainArea() {
		
		slide= new CardLayout();
		this.setLayout(slide);
		this.setBorder(new LineBorder(Color.MAGENTA,2));
		this.setPreferredSize(new Dimension(WIDTH - 2 * MainWindow.PLAYER_WIDTH, MainWindow.HEIGHT - MainWindow.TOP_HEIGHT));
		this.setBackground(Color.WHITE);
		
		hall=new HallOfFame();
		this.add("H",hall);
		
		board=new Board();
		this.add("B",board);
		
	}
  
}
