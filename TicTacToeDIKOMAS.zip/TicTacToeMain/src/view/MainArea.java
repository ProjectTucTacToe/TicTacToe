package view;

import java.awt.CardLayout;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import controller.GameController;
public class MainArea extends JPanel{
	CardLayout slide;
	HallOfFame hall;
	Board board;
	public MainArea(GameController gc) {
		
		slide= new CardLayout();
		this.setLayout(slide);
		this.setBorder(new LineBorder(Color.MAGENTA,2));
		this.setPreferredSize(new Dimension(WIDTH - 2 * MainWindow.PLAYER_WIDTH, MainWindow.HEIGHT - MainWindow.TOP_HEIGHT));
		this.setBackground(Color.WHITE);
		
		hall=new HallOfFame(gc);
		this.add("H",hall);
		
		board=new Board(gc);
		this.add("B",board);
		
	}
  
}
