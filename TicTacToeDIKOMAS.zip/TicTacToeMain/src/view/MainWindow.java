package view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import javax.swing.JFrame;
import controller.GameController;

public class MainWindow extends JFrame {
	
	static public final int WIDTH = 1200;
	static public final int HEIGHT = 800;
	static public final int TOP_HEIGHT = 80;
	static public final int PLAYER_WIDTH = 300;
	
	
	private PlayerPanel left;
	private PlayerPanel right;
	private TopPanel topPanel;
	private MainArea main;
	GameController gc;

	public MainWindow (GameController gc) {
		super("Tic-Tac-Toe");
		this.gc=gc;
		Container c = getContentPane();
		c.setPreferredSize(new Dimension(WIDTH,HEIGHT));
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		
		this.topPanel=new TopPanel(gc);
		c.add(topPanel,BorderLayout.PAGE_START);
		
		this.left=new PlayerPanel(gc,0); //0=left
		c.add(left,BorderLayout.LINE_START);
		
		this.right=new PlayerPanel(gc,1); //0=left
		c.add(right,BorderLayout.LINE_END);
		
		this.main=new MainArea(gc);
		c.add(main,BorderLayout.CENTER);
		
		this.pack();
		
	}
	public static void main (String[] args) {
		GameController gc = new GameController();
		gc.start();
	}
}
