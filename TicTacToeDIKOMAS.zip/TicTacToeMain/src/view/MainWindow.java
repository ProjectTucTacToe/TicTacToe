package view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import javax.swing.JFrame;


public class MainWindow extends JFrame {
	
	static public final int WIDTH = 1200;
	static public final int HEIGHT = 800;
	static public final int TOP_HEIGHT = 80;
	static public final int PLAYER_WIDTH = 300;
	
	
	private PlayerPanel left;
	private PlayerPanel right;
	private TopPanel topPanel;
	private MainArea main;

	public MainWindow () {
		super("Tic-Tac-Toe");
		Container c = getContentPane();
		c.setPreferredSize(new Dimension(WIDTH,HEIGHT));
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		
		this.topPanel=new TopPanel();
		c.add(topPanel,BorderLayout.PAGE_START);
		
		this.left=new PlayerPanel(0); //0=left
		c.add(left,BorderLayout.LINE_START);
		
		this.right=new PlayerPanel(0); //0=left
		c.add(right,BorderLayout.LINE_END);
		
		this.main=new MainArea();
		c.add(main,BorderLayout.CENTER);
		
		this.pack();
		
	}
	public static void main (String[] args) {
		MainWindow w = new MainWindow();
	}
}
