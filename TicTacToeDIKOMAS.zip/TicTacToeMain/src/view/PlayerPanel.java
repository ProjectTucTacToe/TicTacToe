package view;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Arrays;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;


public class PlayerPanel extends JPanel{
    static public final int BUTTON_WIDTH = 100;
	static public final int BUTTON_HEIGHT = 40;
	
	JButton selectPlayer;
	JTextField name;
	int position;

	public PlayerPanel(int position) {
		this.position=position;
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setPreferredSize(new Dimension(MainWindow.PLAYER_WIDTH, MainWindow.HEIGHT-MainWindow.TOP_HEIGHT));
		this.setBorder(new LineBorder(Color.CYAN,1));
		
		selectPlayer=new JButton("Choose Player");
		selectPlayer.setPreferredSize(new Dimension(BUTTON_WIDTH,BUTTON_HEIGHT));
		selectPlayer.setAlignmentX(CENTER_ALIGNMENT);
		this.add(selectPlayer);
		
		name= new JTextField();
		name.setHorizontalAlignment(JTextField.CENTER);
		name.setPreferredSize(new Dimension(BUTTON_WIDTH,BUTTON_HEIGHT));
		name.setAlignmentX(CENTER_ALIGNMENT);
		name.setEnabled(false); // we dont wanna change the names
		this.add(name);
	}
}
