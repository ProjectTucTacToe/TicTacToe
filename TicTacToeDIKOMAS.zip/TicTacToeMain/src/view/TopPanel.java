package view;
import javax.swing.JPanel;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.border.LineBorder;

public class TopPanel extends JPanel{
  static public final int BUTTON_WIDTH = 100;
  static public final int BUTTON_HEIGHT = 40;
 
  private JButton start;
  private JButton done;
  private JButton quit;

	public TopPanel() {
		this.setPreferredSize(new Dimension(MainWindow.WIDTH,MainWindow.TOP_HEIGHT));
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.setBorder(new LineBorder(Color.BLUE,1));
	    
		this.start= new JButton("Start");
		this.start.setPreferredSize(new Dimension(BUTTON_WIDTH,BUTTON_HEIGHT));
		this.start.setEnabled(false);
	    this.add(this.start);
	   
	    this.done= new JButton("Done");
	    this.done.setPreferredSize(new Dimension(BUTTON_WIDTH,BUTTON_HEIGHT));
		this.done.setEnabled(false);
	    this.add(this.done);

        this.quit= new JButton("Quit");
        this.quit.setPreferredSize(new Dimension(BUTTON_WIDTH,BUTTON_HEIGHT));
        ActionListener quitListener = new QuitListener(); 
        this.quit.addActionListener(new QuitListener());
	    this.add(this.quit);
	
	}
	
	private class QuitListener implements ActionListener{
		@Override
		public void actionPerformed (ActionEvent e) {
			System.out.println("Ciao");
			System.exit(0);
		}
	}
	
}
