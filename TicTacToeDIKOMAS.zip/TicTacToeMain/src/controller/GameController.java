package controller;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import model.Board;
//import model.PlayerRoster;
//import model.Player;
//import model.GameRecord;
//import view.MainArea;
import view.MainWindow;


public class GameController extends WindowAdapter{
	MainWindow view;
	Board model;
	public GameController() {		
		
	}
	
	@Override
	public void windowClosing(WindowEvent event) {
		quit();
	}
	public void quit() {		
		System.out.println("Adios...");		
		System.exit(0);
	}
	public void start() {
		this.view= new MainWindow(this); //reference to view  reference sto model 
		this.view.addWindowListener(this);
		this.view.setVisible(true);
		this.model= new Board(this);// reference to model 
	}
}
