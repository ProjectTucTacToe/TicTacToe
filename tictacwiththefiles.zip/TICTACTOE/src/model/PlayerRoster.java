package model;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class PlayerRoster {
	
private Player[] listOfPlayers;
private int numOfPlayers;

public PlayerRoster() {
	listOfPlayers=new Player[40];
}


public void addPlayer(String name) {

	Player playerObj = new Player(name,0,0,0,0,0);

  //  initListOfPlayers();
	loadListOfPlayers();
	storeListOfPlayers(playerObj);
	
	
}


public void loadListOfPlayers() {
	
	try {    

		   
		    FileInputStream fis = new FileInputStream("ListOfPlayers.txt");
		    ObjectInputStream ois = new ObjectInputStream(fis);
		    int i=0;
		    while(fis.available()>0){
		    	
		    	Player p= (Player)ois.readObject();
		    	this.listOfPlayers[i]=p;
		    	
		    	i++;
		    	}
		    fis.close();
		    ois.close();
		}
		catch (FileNotFoundException e) {
		    e.printStackTrace();
		}
		catch (IOException e) {
		    e.printStackTrace();
		}
	    catch (ClassNotFoundException e) {
		   e.printStackTrace();
		}
}

public void storeListOfPlayers(Player player) {

	for(int j=0; j<50; j++) {
		if(this.listOfPlayers[j]==null) {
			this.listOfPlayers[j]=player;
			try {    

			    FileOutputStream fos = new FileOutputStream("ListOfPlayers.txt");
			    ObjectOutputStream oos = new ObjectOutputStream(fos);
			    j=0;
			   for(Player p : this.listOfPlayers) {			  
				  if(this.listOfPlayers[j]==null) {
					  break;
				  }
				  else{
				   oos.writeObject(p);
				  }
				  j++;
			   }
			    fos.close();
			    oos.close();
			}
			catch (FileNotFoundException e) {
			    e.printStackTrace();
			}
			catch (IOException e) {
			    e.printStackTrace();
			}
		    return;
		}else
			System.out.println(this.listOfPlayers[j].getName());
			
	}
}

public void initListOfPlayers() {
	
	Player plr1[] = {null,null};
	
	try {
		
		 FileInputStream fis = new FileInputStream("ListOfPlayers.txt");	
		 System.out.println(fis.available());
		 
		if(fis.available()==4) {

			 FileOutputStream fos = new FileOutputStream("ListOfPlayers.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);	
			
		 for(Player p : plr1) {
			//this.listOfPlayers=null;
			   oos.writeObject(p);
		   }
			
		 oos.close();
		 fos.close();
		}
		else {
			
			fis.close();
			return;
		}
		
		 fis.close();
		   
	} catch (FileNotFoundException e1) {
		e1.printStackTrace();
	}	
	 catch (IOException e) {
		e.printStackTrace();
	}
	
}



public void findPlayerNames(){
	
};
public void findPlayer(){
};
public void findHallOfFame() {

};


}
