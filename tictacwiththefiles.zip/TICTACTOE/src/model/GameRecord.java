package model;
import java.io.Serializable;
import java.time.LocalDate; 

public class GameRecord implements Comparable<GameRecord>, Serializable{
	
	 private static final long serialVersionUID = 1L;
	
private Player playerX;
private Player playerO;
private int scoreX;//BEFORE THE GAME
private int scoreO;//BEFORE THE GAME
private int result;
private LocalDate date;


@Override
public int compareTo(GameRecord g) {
	 return getDate().compareTo(g.getDate());
}
public int compareToResult(GameRecord g) {
	 if(this.result>g.result) {
		 return 1;
	 }
	 if (this.result == g.result)
		 return 0;
	 return -1;
}


//Getters and Setters
public int getScoreX() {
	return scoreX;
}



public void setScoreX(int scoreX) {
	this.scoreX = scoreX;
}



public int getScoreO() {
	return scoreO;
}



public void setScoreO(int scoreO) {
	this.scoreO = scoreO;
}



public Player getPlayerX() {
	return playerX;
}
public void setPlayerX(Player playerX) {
	this.playerX = playerX;
}
public Player getPlayerO() {
	return playerO;
}
public void setPlayerO(Player playerO) {
	this.playerO = playerO;
}

public int getResult() {
	return result;
}

public void setResult(int result) {
	this.result = result;
}



public LocalDate getDate() {
	return date;
}
public void setDate(LocalDate date) {
	this.date = date;
}







}
