package model;
import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);	
	     System.out.println("enter name of player");
	     String nameOfPlayer = input.nextLine();
		
	    PlayerRoster obj = new PlayerRoster();
	    
	   obj.initListOfPlayers();
	   obj.addPlayer(nameOfPlayer);
	   obj.loadListOfPlayers();
	     
	 
	     input.close();

	}

}
