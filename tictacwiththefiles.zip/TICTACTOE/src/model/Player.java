package model;

import java.io.Serializable;

public class Player implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	
  private String name;
  private int numOfWins;
  private int numOfGames;
  private int numOfLoses;
  private int numOfDraws;
  private GameRecord[] records;
  private float score;
  private GameRecord[] bestGames;
  private GameRecord[] newGames;
  

//Contructor arg
public Player(String name,int numOfWins,int numOfGames,int numOfLoses,int numOfDraws, float score){
	this.name =name;
	this.numOfWins =numOfWins;
    this.numOfGames =numOfGames;
	this.numOfLoses=numOfLoses;
	this.numOfDraws=numOfDraws;
	this.score=score;
	this.records=new GameRecord[40];
	this.newGames= new GameRecord[5];
	bestGames= new GameRecord[5];
}

public Player() {
}



public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getNumOfWins() {
	return numOfWins;
}

public void setNumOfWins(int numOfWins) {
	this.numOfWins = numOfWins;
}

public int getNumOfGames() {
	return numOfGames;
}

public void setNumOfGames(int numOfGames) {
	this.numOfGames = numOfGames;
}

public int getNumOfLoses() {
	return numOfLoses;
}

public void setNumOfLoses(int numOfLoses) {
	this.numOfLoses = numOfLoses;
}

public int getNumOfDraws() {
	return numOfDraws;
}

public void setNumOfDraws(int numOfDraws) {
	this.numOfDraws = numOfDraws;
}

public GameRecord[] getRecords() {
	return records;
}

public void setRecords(GameRecord[] records) {
	this.records = records;
}

public float getScore() {
	return score;
}

public void setScore(float score) {
	this.score = score;
}

public GameRecord[] getNewGames() {
	return newGames;
}

public void setNewGames(GameRecord[] newGames) {
	this.newGames = newGames;
}




public float scoreCalculator() {
	
	if(numOfGames==0) {
		score=0;
		return score;
	}
	else
	return score = 50*(2*numOfWins+numOfDraws)/numOfGames;
}
//mehtod gia ta 5 kalitera
/*public void topGames() {
	 for (int i = 0 ; i < numOfGames; i++) {

         for(int j=i+1; j<numOfGames; j++) {
      	   
         if( records [j].compareTo( records [i]) > 0 ) {
      	 
      	 GameRecord temp;
             temp=records[j];

             records[j]=records[i];

             records[i]=temp;
     
         }
		 
		 
		 
		 
	 }
	
	if (numOfWins >=5) {
		
		
		
	}
	 
	 
	 
}
}
*/


//method gia ta 5 pio prosfata
public void newestGames() {
	
	   for (int i = 0 ; i < numOfGames; i++) {

           for(int j=i+1; j<numOfGames; j++) {
        	   
           if( records [j].compareTo( records [i]) > 0 ) {
        	 
        	 GameRecord temp;
               temp=records[j];

               records[j]=records[i];

               records[i]=temp;
       
           }


}
}
	   System.arraycopy(records, 0, newGames, 0, 5);
  
}

//method for sorting into 3 arrays
public void sort () {
	 for (int i = 0 ; i < numOfGames; i++) {
	// if (records[i].result == 1) {
	 
	// }
}

}
}

